
package com.csc2002s.assgnmnts.apps.alphabetapplication.macrobenchmark

const val PACKAGE_NAME = "com.csc2002s.assgnmnts.apps.alphabetapplication"
