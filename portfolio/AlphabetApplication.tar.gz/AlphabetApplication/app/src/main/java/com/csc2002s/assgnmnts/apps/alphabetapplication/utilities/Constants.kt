package com.csc2002s.assgnmnts.apps.alphabetapplication.utilities

/**
 * Constants used throughout the app.
 */
const val DATABASE_NAME = "alphabetapplication-db"
const val ALPHABET_DATA_FILENAME = "alphabets.json"
